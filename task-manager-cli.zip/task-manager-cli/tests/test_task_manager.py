import json

import pytest

import task_manager


@pytest.fixture
def data_file(tmp_path, monkeypatch):
    path = tmp_path / "tasks.json"
    monkeypatch.setattr(task_manager, "DATA_FILE", path)
    return path


def test_add_task_saves_pending_task(data_file, capsys):
    task_manager.main(["add", "Finish assignment", "--due", "2026-10-20"])

    tasks = json.loads(data_file.read_text(encoding="utf-8"))
    assert len(tasks) == 1
    assert tasks[0]["title"] == "Finish assignment"
    assert tasks[0]["status"] == "pending"
    assert tasks[0]["due_date"] == "2026-10-20"
    assert "Added task #1" in capsys.readouterr().out


def test_list_filters_by_status(data_file, capsys):
    task_manager.main(["add", "Pending task"])
    task_manager.main(["add", "Another task"])
    task_manager.main(["complete", "2"])
    capsys.readouterr()  # Ignore output from setup commands.

    task_manager.main(["list", "--status", "pending"])
    output = capsys.readouterr().out
    assert "Pending task" in output
    assert "Another task" not in output


def test_list_filters_by_due_date(data_file, capsys):
    task_manager.main(["add", "Due today", "--due", "2026-10-20"])
    task_manager.main(["add", "Due later", "--due", "2026-10-21"])
    capsys.readouterr()  # Ignore output from setup commands.

    task_manager.main(["list", "--due", "2026-10-20"])
    output = capsys.readouterr().out
    assert "Due today" in output
    assert "Due later" not in output


def test_complete_and_delete_task(data_file, capsys):
    task_manager.main(["add", "Temporary task"])
    task_manager.main(["complete", "1"])
    assert json.loads(data_file.read_text(encoding="utf-8"))[0]["status"] == "completed"

    task_manager.main(["delete", "1"])
    assert json.loads(data_file.read_text(encoding="utf-8")) == []
    assert "Deleted task #1" in capsys.readouterr().out


def test_invalid_due_date_is_rejected():
    with pytest.raises(SystemExit):
        task_manager.main(["add", "Bad date", "--due", "20-10-2026"])
