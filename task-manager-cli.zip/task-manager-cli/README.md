# Task Manager CLI

A small command-line task manager built with Python's `argparse`. Tasks are saved in a JSON file, so they persist between runs.

## Features

- Add, list, complete, and delete tasks.
- Filter tasks by status (`pending` or `completed`).
- Filter tasks by an exact due date.
- Validate due dates in `YYYY-MM-DD` format.
- Persist tasks in a JSON file.
- Automated tests using `pytest`.

## Requirements

- Python 3.9 or newer
- `pytest` to run the test suite

## Setup

Open a terminal in this project folder and install the test dependency:

```bash
python -m pip install -r requirements.txt
```

On some Windows installations, use `py` instead of `python`.

## Usage

Add a task:

```bash
python task_manager.py add "Finish Python assignment" --due 2026-10-20
```

Add a task without a due date:

```bash
python task_manager.py add "Read chapter 3"
```

List all tasks:

```bash
python task_manager.py list
```

Filter by status:

```bash
python task_manager.py list --status pending
python task_manager.py list --status completed
```

Filter by exact due date:

```bash
python task_manager.py list --due 2026-10-20
```

Complete a task using its ID:

```bash
python task_manager.py complete 1
```

Delete a task using its ID:

```bash
python task_manager.py delete 1
```

Show available commands and options:

```bash
python task_manager.py --help
python task_manager.py list --help
```

## Data storage

By default, tasks are saved to `~/.task-manager/tasks.json` (inside your user home directory). To use a different file, set the `TASK_MANAGER_DATA` environment variable before running the program.

Windows Command Prompt:

```bat
set TASK_MANAGER_DATA=tasks.json
python task_manager.py list
```

PowerShell:

```powershell
$env:TASK_MANAGER_DATA = "tasks.json"
python task_manager.py list
```

## Run the tests

```bash
python -m pytest -v
```

The test suite checks adding tasks, filtering by status and due date, completing and deleting tasks, and invalid date handling.

## Design notes

This project intentionally uses a simple JSON file instead of a database so it is easy to run and review. Each task has an integer ID, a title, an optional due date, and a status. The command-line interface uses `argparse` subcommands rather than an interactive menu.
