"""A small command-line task manager with JSON persistence."""

import argparse
import json
import os
import sys
from datetime import date
from pathlib import Path

DATA_FILE = Path(
    os.environ.get("TASK_MANAGER_DATA", Path.home() / ".task-manager" / "tasks.json")
)


def load_tasks():
    """Load tasks from the JSON file, returning an empty list if it does not exist."""
    if not DATA_FILE.exists():
        return []
    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            tasks = json.load(file)
        if not isinstance(tasks, list):
            raise ValueError("Task data must be a JSON list.")
        return tasks
    except (json.JSONDecodeError, OSError, ValueError) as exc:
        raise RuntimeError(f"Could not read task data at {DATA_FILE}: {exc}") from exc


def save_tasks(tasks):
    """Save tasks to the JSON file, creating its parent directory if needed."""
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(tasks, file, indent=2)


def validate_date(value):
    """Validate and return a date in YYYY-MM-DD format."""
    try:
        return date.fromisoformat(value).isoformat()
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "Date must use YYYY-MM-DD format, for example 2026-12-31."
        ) from exc


def command_add(args):
    tasks = load_tasks()
    next_id = max((task["id"] for task in tasks), default=0) + 1
    task = {
        "id": next_id,
        "title": args.title,
        "due_date": args.due,
        "status": "pending",
    }
    tasks.append(task)
    save_tasks(tasks)
    print(f"Added task #{next_id}: {args.title}")


def command_list(args):
    tasks = load_tasks()

    if args.status:
        tasks = [task for task in tasks if task["status"] == args.status]
    if args.due:
        tasks = [task for task in tasks if task["due_date"] == args.due]

    if not tasks:
        print("No tasks found.")
        return

    for task in sorted(tasks, key=lambda item: item["id"]):
        due = task["due_date"] or "No due date"
        print(f'#{task["id"]} [{task["status"]}] {task["title"]} (due: {due})')


def command_complete(args):
    tasks = load_tasks()
    for task in tasks:
        if task["id"] == args.task_id:
            if task["status"] == "completed":
                print(f'Task #{args.task_id} is already completed.')
                return
            task["status"] = "completed"
            save_tasks(tasks)
            print(f'Completed task #{args.task_id}: {task["title"]}')
            return
    print(f"Task #{args.task_id} was not found.", file=sys.stderr)
    raise SystemExit(1)


def command_delete(args):
    tasks = load_tasks()
    remaining = [task for task in tasks if task["id"] != args.task_id]
    if len(remaining) == len(tasks):
        print(f"Task #{args.task_id} was not found.", file=sys.stderr)
        raise SystemExit(1)
    save_tasks(remaining)
    print(f"Deleted task #{args.task_id}.")


def build_parser():
    parser = argparse.ArgumentParser(
        prog="task-manager",
        description="Manage tasks from your command line.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    add_parser = subparsers.add_parser("add", help="Add a task")
    add_parser.add_argument("title", help="Task title")
    add_parser.add_argument(
        "--due", type=validate_date, help="Due date in YYYY-MM-DD format"
    )
    add_parser.set_defaults(func=command_add)

    list_parser = subparsers.add_parser("list", help="List and filter tasks")
    list_parser.add_argument(
        "--status", choices=("pending", "completed"), help="Filter by task status"
    )
    list_parser.add_argument(
        "--due", type=validate_date, help="Show tasks due on this date"
    )
    list_parser.set_defaults(func=command_list)

    complete_parser = subparsers.add_parser("complete", help="Mark a task complete")
    complete_parser.add_argument("task_id", type=int, help="ID of the task")
    complete_parser.set_defaults(func=command_complete)

    delete_parser = subparsers.add_parser("delete", help="Delete a task")
    delete_parser.add_argument("task_id", type=int, help="ID of the task")
    delete_parser.set_defaults(func=command_delete)

    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        args.func(args)
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
